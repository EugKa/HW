import { createButton } from './components/lamp/lamp.js';
const btnRoot = document.querySelector('#lamp');
// createButton(btnRoot, 'red', 3000);



const getNumber = (minValue = 500, maxValue = 5000) => {
    const randomNumber = Math.floor(Math.random() * (maxValue - minValue)) + minValue;
    return randomNumber;
};

const col = ['red', 'yellow', 'green', 'blue',
    'orange', 'brown', 'purple', 'aqua',
    'burlywood', 'darkgoldenrod', 'fuchsia',
    'cornflowerblue', 'orangered', 'darkred',
    'lime', 'teal', 'navy', 'indigo',
    'mediumvioletred', 'oldlace'];

const christmasLights = (count = 20) => {
    for (let i = 0; i < count; i++) {
        createButton(btnRoot, col[i], getNumber(), 100);
    }
}
christmasLights();



