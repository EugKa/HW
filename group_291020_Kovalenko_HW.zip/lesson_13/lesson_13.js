import { createController } from './catalog/catalogController.js';

createController();